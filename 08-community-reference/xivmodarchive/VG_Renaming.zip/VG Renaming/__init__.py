bl_info = { 
    "name": "Vertex Group Rename by JSON Mapping + Auto Bone Mapping",
    "author": "ChatGPT & Coldship",
    "version": (1, 2, 0),
    "blender": (3, 0, 0),
    "location": "View3D > Sidebar > Rename Tools",
    "description": "Rename bones and vertex groups using a JSON mapping file + auto bone mapping with forced rules",
    "category": "Rigging",
}

import bpy
import json
import os
import mathutils


# ---------------------------------------------------
# 读取 JSON 映射表
# ---------------------------------------------------
def load_mapping(path):
    with open(path, "r", encoding="utf8") as f:
        mapping = json.load(f)
    if not isinstance(mapping, dict):
        raise ValueError("JSON 文件不是 {old: new} 格式")
    return mapping


# ---------------------------------------------------
# 顶点组重命名
# ---------------------------------------------------
def rename_vertex_groups(obj, mapping):
    if obj.type != "MESH":
        return 0

    count = 0
    for old, new in mapping.items():
        if old in obj.vertex_groups:
            obj.vertex_groups[old].name = new
            count += 1

    return count


# ---------------------------------------------------
# 骨骼重命名
# ---------------------------------------------------
def rename_bones(obj, mapping):
    if obj.type != "ARMATURE":
        return 0

    arm = obj.data
    count = 0

    bpy.ops.object.mode_set(mode='EDIT')

    for old, new in mapping.items():
        bone = arm.edit_bones.get(old)
        if bone:
            bone.name = new
            count += 1

    bpy.ops.object.mode_set(mode='OBJECT')
    return count


# ---------------------------------------------------
# 自动生成骨骼映射表（基于最小距离 + 强制规则）
# ---------------------------------------------------
def generate_bone_mapping(arm_src, arm_dst):
    mapping = {}

    src_bones = arm_src.data.bones
    dst_bones = arm_dst.data.bones

    # 提取世界空间位置
    src_pos = {b.name: arm_src.matrix_world @ b.head_local for b in src_bones}
    dst_pos = {b.name: arm_dst.matrix_world @ b.head_local for b in dst_bones}

    for s_name, s_pos in src_pos.items():
        best = None
        best_dist = 999999999

        for d_name, d_pos in dst_pos.items():
            dist = (s_pos - d_pos).length
            if dist < best_dist:
                best_dist = dist
                best = d_name

        if best:
            mapping[s_name] = best

    # ----- 强制修正规则 -----
    forced_mapping = {
        "shoulder_twist_L": "n_hkata_l",
        "shoulder_twist_R": "n_hkata_r",
        "rootX_M": "j_kosi",
        "shoulder_R": "j_ude_a_r",
        "shoulder_L": "j_ude_a_l",
        "elbow_R": "j_ude_b_r",
        "elbow_L": "j_ude_b_l",
        "elbow_twist_R": "n_hhiji_r",
        "elbow_twist_L": "n_hhiji_l",
        "wrist_R": "j_te_r",
        "wrist_L": "j_te_l",
        "wrist_twist_R": "n_hte_r",
        "wrist_twist_L": "n_hte_l",
        "spine1_M": "j_sebo_a",
        "hip_R": "j_asi_a_r",
        "hip_L": "j_asi_a_l",
    }

    for src, dst in forced_mapping.items():
        if src in mapping:
            mapping[src] = dst

    return mapping


# ---------------------------------------------------
# 文件输出 Operator（默认文件名 + 强制 .json）
# ---------------------------------------------------
class RENAME_OT_export_mapping(bpy.types.Operator):
    bl_idname = "rename.export_bone_mapping"
    bl_label = "Generate Bone Mapping JSON（A→B）"
    bl_description = "Active = A，Selected = B，Generate JSON"

    filepath: bpy.props.StringProperty(subtype="FILE_PATH")

    def execute(self, context):
        objs = context.selected_objects
        active = context.object

        if not active or active.type != "ARMATURE":
            self.report({'ERROR'}, "激活物体必须是骨架 A（源）")
            return {'CANCELLED'}

        target = None
        for o in objs:
            if o != active and o.type == "ARMATURE":
                target = o
                break

        if not target:
            self.report({'ERROR'}, "必须选择两个骨架：激活 = A，另一个 = B")
            return {'CANCELLED'}

        # 生成映射
        mapping = generate_bone_mapping(active, target)

        # 强制 .json 后缀
        path = bpy.path.abspath(self.filepath)
        if not path.lower().endswith(".json"):
            path += ".json"

        with open(path, "w", encoding="utf8") as f:
            json.dump(mapping, f, indent=4, ensure_ascii=False)

        self.report({'INFO'}, f"已输出骨骼映射到 {path}")
        return {'FINISHED'}

    def invoke(self, context, event):
        # 默认文件名
        self.filepath = bpy.path.abspath("//bone_mapping.json")
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}


# ---------------------------------------------------
# UI 面板（原样保留，仅添加新按钮）
# ---------------------------------------------------
class RENAME_PT_panel(bpy.types.Panel):
    bl_label = "VG Rename (JSON)"
    bl_idname = "RENAME_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Rename Tools"

    def draw(self, context):
        layout = self.layout
        props = context.scene.rename_mapping_props

        layout.prop(props, "mapping_path")
        layout.separator()

        layout.prop(props, "apply_bones")
        layout.prop(props, "apply_vgroups")
        layout.separator()

        layout.operator("rename.apply_mapping", icon="EXPORT")

        layout.separator()
        layout.label(text="Auto Bone Remapping (nearest)")
        layout.label(text="Active Object A= Mobile Armature")
        layout.label(text="Selected Object B = FFXIV Armature")
        layout.operator("rename.export_bone_mapping", icon="FILE_TICK")


# ---------------------------------------------------
# 属性
# ---------------------------------------------------
class RenameMappingProperties(bpy.types.PropertyGroup):
    mapping_path: bpy.props.StringProperty(
        name="Mapping JSON",
        description="Select a JSON mapping file",
        subtype="FILE_PATH"
    )

    apply_bones: bpy.props.BoolProperty(
        name="Rename Bones",
        default=False
    )

    apply_vgroups: bpy.props.BoolProperty(
        name="Rename Vertex Groups",
        default=True
    )


# ---------------------------------------------------
# Operator: 执行 JSON 重命名
# ---------------------------------------------------
class RENAME_OT_apply(bpy.types.Operator):
    bl_idname = "rename.apply_mapping"
    bl_label = "Apply Mapping"

    def execute(self, context):
        props = context.scene.rename_mapping_props
        json_path = bpy.path.abspath(props.mapping_path)

        if not os.path.exists(json_path):
            self.report({'ERROR'}, "JSON 文件不存在")
            return {'CANCELLED'}

        try:
            mapping = load_mapping(json_path)
        except Exception as e:
            self.report({'ERROR'}, f"JSON 读取失败: {e}")
            return {'CANCELLED'}

        sel = context.selected_objects
        if not sel:
            self.report({'ERROR'}, "请选择对象（Mesh 或 Armature）")
            return {'CANCELLED'}

        total_b = 0
        total_v = 0

        for obj in sel:
            if props.apply_vgroups:
                total_v += rename_vertex_groups(obj, mapping)

            if props.apply_bones and obj.type == "ARMATURE":
                total_b += rename_bones(obj, mapping)

        self.report({'INFO'}, f"完成：骨骼 {total_b}, 顶点组 {total_v}")
        return {'FINISHED'}


# ---------------------------------------------------
# 注册
# ---------------------------------------------------
classes = (
    RenameMappingProperties,
    RENAME_PT_panel,
    RENAME_OT_apply,
    RENAME_OT_export_mapping,
)


def register():
    for c in classes:
        bpy.utils.register_class(c)

    bpy.types.Scene.rename_mapping_props = bpy.props.PointerProperty(
        type=RenameMappingProperties
    )


def unregister():
    for c in reversed(classes):
        bpy.utils.unregister_class(c)

    del bpy.types.Scene.rename_mapping_props


if __name__ == "__main__":
    register()
