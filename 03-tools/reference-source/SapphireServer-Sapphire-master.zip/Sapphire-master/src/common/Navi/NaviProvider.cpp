#include <Common.h>
#include <Logging/Logger.h>

#include <Random/RNGMgr.h>

#include "NavMeshCacheIO.h"
#include "NaviProvider.h"

#include <recastnavigation/Detour/Include/DetourNavMesh.h>
#include <recastnavigation/Detour/Include/DetourNavMeshQuery.h>
#include <DetourCommon.h>
#include <recastnavigation/Recast/Include/Recast.h>
#include <filesystem>
#include <fstream>
#include <Service.h>

Sapphire::Common::Navi::NaviProvider::NaviProvider( const std::string& internalName ) :
  m_naviMesh( nullptr ),
  m_naviMeshQuery( nullptr ),
  m_internalName( internalName )
{
  // Set defaults
  m_polyFindRange[ 0 ] = 20;
  m_polyFindRange[ 1 ] = 20;
  m_polyFindRange[ 2 ] = 20;
}

bool Sapphire::Common::Navi::NaviProvider::init( const std::string& naviPath )
{
  m_naviPath = naviPath;
  auto meshesFolder = std::filesystem::path( naviPath );
  auto meshFolder = meshesFolder / std::filesystem::path( m_internalName );

  if( std::filesystem::exists( meshFolder ) )
  {
    auto baseMesh = meshFolder / std::filesystem::path( m_internalName + ".nav" );

    if( !loadMesh( baseMesh.string() ) )
      return false;

    m_pCrowd = std::make_unique< dtCrowd >();

    if( !m_pCrowd->init( 1000, 10.f, m_naviMesh ) )
      return false;

    dtObstacleAvoidanceParams params;
    // Use mostly default settings, copy from dtCrowd.
    memcpy(&params, m_pCrowd->getObstacleAvoidanceParams(0), sizeof(dtObstacleAvoidanceParams));

    // Low (11)
    params.velBias = 0.5f;
    params.adaptiveDivs = 5;
    params.adaptiveRings = 2;
    params.adaptiveDepth = 1;
    m_pCrowd->setObstacleAvoidanceParams(0, &params);

    // Medium (22)
    params.velBias = 0.5f;
    params.adaptiveDivs = 5;
    params.adaptiveRings = 2;
    params.adaptiveDepth = 2;
    m_pCrowd->setObstacleAvoidanceParams(1, &params);

    // Good (45)
    params.velBias = 0.5f;
    params.adaptiveDivs = 7;
    params.adaptiveRings = 2;
    params.adaptiveDepth = 3;
    m_pCrowd->setObstacleAvoidanceParams(2, &params);

    // High (66)
    params.velBias = 0.5f;
    params.adaptiveDivs = 7;
    params.adaptiveRings = 3;
    params.adaptiveDepth = 3;

    m_pCrowd->setObstacleAvoidanceParams(3, &params);

    m_vod = dtAllocObstacleAvoidanceDebugData();
    m_vod->init( 2048 );

    initQuery();

    return true;
  }

  return false;
}

bool Sapphire::Common::Navi::NaviProvider::hasNaviMesh() const
{
  return m_naviMesh != nullptr;
}

void Sapphire::Common::Navi::NaviProvider::initQuery()
{
  if( m_naviMeshQuery )
    dtFreeNavMeshQuery( m_naviMeshQuery );

  m_naviMeshQuery = dtAllocNavMeshQuery();
  m_naviMeshQuery->init( m_naviMesh, 2048 );
}

int32_t Sapphire::Common::Navi::NaviProvider::fixupCorridor( dtPolyRef* path, const int32_t npath, const int32_t maxPath,
                                                            const dtPolyRef* visited, const int32_t nvisited )
{
  int32_t furthestPath = -1;
  int32_t furthestVisited = -1;

  // Find furthest common polygon.
  for( int32_t i = npath - 1; i >= 0; --i )
  {
    bool found = false;
    for( int32_t j = nvisited - 1; j >= 0; --j )
    {
      if( path[ i ] == visited[ j ] )
      {
        furthestPath = i;
        furthestVisited = j;
        found = true;
      }
    }
    if( found )
      break;
  }

  // If no intersection found just return current path. 
  if( furthestPath == -1 || furthestVisited == -1 )
    return npath;

  // Concatenate paths.	

  // Adjust beginning of the buffer to include the visited.
  const int32_t req = nvisited - furthestVisited;
  const int32_t orig = rcMin( furthestPath + 1, npath );
  int32_t size = rcMax( 0, npath - orig );
  if( req + size > maxPath )
    size = maxPath - req;
  if( size )
    memmove( path + req, path + orig, size * sizeof( dtPolyRef ) );

  // Store visited
  for( int32_t i = 0; i < req; ++i )
    path[i] = visited[( nvisited - 1 ) - i];

  return req + size;
}

int32_t Sapphire::Common::Navi::NaviProvider::fixupShortcuts( dtPolyRef* path, int32_t npath, dtNavMeshQuery* navQuery )
{
  if( npath < 3 )
    return npath;

  // Get connected polygons
  const int32_t maxNeis = 16;
  dtPolyRef neis[ maxNeis ];
  int32_t nneis = 0;

  const dtMeshTile* tile = 0;
  const dtPoly* poly = 0;
  if( dtStatusFailed( navQuery->getAttachedNavMesh()->getTileAndPolyByRef( path[ 0 ], &tile, &poly ) ) )
    return npath;

  for( uint32_t k = poly->firstLink; k != DT_NULL_LINK; k = tile->links[ k ].next )
  {
    const dtLink* link = &tile->links[ k ];
    if( link->ref != 0 )
    {
      if( nneis < maxNeis )
        neis[ nneis++ ] = link->ref;
    }
  }

  // If any of the neighbour polygons is within the next few polygons
  // in the path, short cut to that polygon directly.
  const int32_t maxLookAhead = 6;
  int32_t cut = 0;
  for( int32_t i = dtMin( maxLookAhead, npath ) - 1; i > 1 && cut == 0; i-- )
  {
    for( int32_t j = 0; j < nneis; j++ )
    {
      if( path[ i ] == neis[ j ] )
      {
        cut = i;
        break;
      }
    }
  }
  if( cut > 1 )
  {
    int32_t offset = cut - 1;
    npath -= offset;
    for( int32_t i = 1; i < npath; i++ )
      path[ i ] = path[ i + offset ];
  }

  return npath;
}

bool Sapphire::Common::Navi::NaviProvider::inRange( const float* v1, const float* v2, const float r, const float h )
{
  const float dx = v2[ 0 ] - v1[ 0 ];
  const float dy = v2[ 1 ] - v1[ 1 ];
  const float dz = v2[ 2 ] - v1[ 2 ];
  return ( dx * dx + dz * dz ) < r * r && fabsf( dy ) < h;
}

bool Sapphire::Common::Navi::NaviProvider::getSteerTarget( dtNavMeshQuery* navQuery, const float* startPos, const float* endPos,
                                                          const float minTargetDist, const dtPolyRef* path, const int32_t pathSize,
                                                          float* steerPos, unsigned char& steerPosFlag, dtPolyRef& steerPosRef,
                                                          float* outPoints, int32_t* outPointCount )
{
  // Find steer target.
  const int32_t MAX_STEER_POINTS = 3;
  float steerPath[ MAX_STEER_POINTS * 3 ];
  uint8_t steerPathFlags[ MAX_STEER_POINTS ];
  dtPolyRef steerPathPolys[ MAX_STEER_POINTS ];
  int32_t nsteerPath = 0;
  navQuery->findStraightPath( startPos, endPos, path, pathSize,
                              steerPath, steerPathFlags, steerPathPolys, &nsteerPath, MAX_STEER_POINTS );
  if( !nsteerPath )
    return false;

  if( outPoints && outPointCount )
  {
    *outPointCount = nsteerPath;
    for( int32_t i = 0; i < nsteerPath; ++i )
      dtVcopy( &outPoints[ i * 3 ], &steerPath[ i * 3 ] );
  }

  // Find vertex far enough to steer to.
  int32_t ns = 0;
  while( ns < nsteerPath )
  {
    // Stop at Off-Mesh link or when point is further than slop away.
    if( ( steerPathFlags[ ns ] & DT_STRAIGHTPATH_OFFMESH_CONNECTION ) ||
        !inRange( &steerPath[ ns * 3 ], startPos, minTargetDist, 1000.0f ) )
      break;
    ns++;
  }
  // Failed to find good point to steer to.
  if( ns >= nsteerPath )
    return false;

  dtVcopy( steerPos, &steerPath[ ns * 3 ] );
  steerPos[ 1 ] = startPos[ 1 ];
  steerPosFlag = steerPathFlags[ ns ];
  steerPosRef = steerPathPolys[ ns ];

  return true;
}

static float frand()
{
  return ( float ) rand() / (float)RAND_MAX;
}


Sapphire::Common::Vector3
  Sapphire::Common::Navi::NaviProvider::findRandomPositionInCircle( const Sapphire::Common::Vector3& startPos,
                                                                   float maxRadius )
{
  dtStatus status;

  float spos[ 3 ] = { startPos.x, startPos.y, startPos.z };

  float polyPickExt[ 3 ];
  polyPickExt[ 0 ] = 30;
  polyPickExt[ 1 ] = 60;
  polyPickExt[ 2 ] = 30;

  float randomPt[ 3 ];
  float snearest[ 3 ];

  dtQueryFilter filter;
  filter.setIncludeFlags( 0xffff );
  filter.setExcludeFlags( 0 );

  dtPolyRef startRef;
  dtPolyRef randomRef;

  status = m_naviMeshQuery->findNearestPoly( spos, polyPickExt, &filter, &startRef, snearest );

  if( dtStatusFailed( status ) )
  {
    return {};
  }

  if( !m_naviMesh->isValidPolyRef( startRef ) )
  {
    return {};
  }

  auto& RNGMgr = Common::Service< Common::Random::RNGMgr >::ref();
  auto rng = RNGMgr.getRandGenerator< float >( 0.f, 1.f );
  status = m_naviMeshQuery->findRandomPointAroundCircle( startRef, spos, maxRadius, &filter, frand,
             &randomRef, randomPt );

  if( dtStatusFailed( status ) )
  {
    return {};
  }

  return { randomPt[ 0 ], randomPt[ 1 ], randomPt[ 2 ] };
}



Sapphire::Common::Vector3
  Sapphire::Common::Navi::NaviProvider::findNearestPosition( float x, float z )
{
  dtStatus status;

  float spos[ 3 ] = { x, 50, z };

  float polyPickExt[ 3 ];
  polyPickExt[ 0 ] = 0.1f;
  polyPickExt[ 1 ] = 300;
  polyPickExt[ 2 ] = 0.1f;
  float snearest[ 3 ];

  dtQueryFilter filter;
  filter.setIncludeFlags( 0xffff );
  filter.setExcludeFlags( 0 );

  dtPolyRef startRef;

  status = m_naviMeshQuery->findNearestPoly( spos, polyPickExt, &filter, &startRef, snearest );

  if( dtStatusFailed( status ) )
  {
    // Key improvement 3: Try with larger search radius if first attempt fails
    polyPickExt[ 0 ] = 0.1f;
    polyPickExt[ 1 ] = 500.0f;
    polyPickExt[ 2 ] = 0.1f;

    status = m_naviMeshQuery->findNearestPoly( spos, polyPickExt, &filter, &startRef, snearest );

    if( dtStatusFailed( status ) )
    {
      return {};
    }
  }


  if( !m_naviMesh->isValidPolyRef( startRef ) )
  {
    return {};
  }

  return { snearest[ 0 ], snearest[ 1 ], snearest[ 2 ] };
}

std::vector< Sapphire::Common::Vector3 >
  Sapphire::Common::Navi::NaviProvider::findFollowPath( const Common::Vector3& startPos,
                                                       const Common::Vector3& endPos )
{
  if( !m_naviMesh || !m_naviMeshQuery )
    throw std::runtime_error( "No navimesh loaded" );

  auto resultCoords = std::vector< Common::Vector3 >();

  dtPolyRef startRef, endRef = 0;

  float spos[ 3 ] = { startPos.x, startPos.y, startPos.z };
  float epos[ 3 ] = { endPos.x, endPos.y, endPos.z };

  dtQueryFilter filter;
  filter.setIncludeFlags( 0xffff );
  filter.setExcludeFlags( 0 );

  m_naviMeshQuery->findNearestPoly( spos, m_polyFindRange, &filter, &startRef, 0 );
  m_naviMeshQuery->findNearestPoly( epos, m_polyFindRange, &filter, &endRef, 0 );

  // Couldn't find any close polys to navigate from
  if( !startRef || !endRef )
    return resultCoords;

  dtPolyRef polys[ MAX_POLYS ];
  int32_t numPolys = 0;

  m_naviMeshQuery->findPath( startRef, endRef, spos, epos, &filter, polys, &numPolys, MAX_POLYS );

  // Check if we got polys back for navigation
  if( numPolys )
  {
    // Iterate over the path to find smooth path on the detail mesh surface.
    memcpy( polys, polys, sizeof( dtPolyRef )*numPolys );
    int32_t npolys = numPolys;

    float iterPos[3], targetPos[3];
    m_naviMeshQuery->closestPointOnPoly( startRef, spos, iterPos, 0 );
    m_naviMeshQuery->closestPointOnPoly( polys[ npolys - 1 ], epos, targetPos, 0 );

    //Logger::debug( "IterPos: {0} {1} {2}; TargetPos: {3} {4} {5}",
    //               iterPos[ 0 ], iterPos[ 1 ], iterPos[ 2 ],
    //               targetPos[ 0 ], targetPos[ 1 ], targetPos[ 2 ] );

    // todo: adjust these for the actor radius
    const float STEP_SIZE = 0.5f;
    const float SLOP = 0.15f;

    int32_t numSmoothPath = 0;
    float smoothPath[ MAX_SMOOTH * 3 ];

    dtVcopy( &smoothPath[ numSmoothPath * 3 ], iterPos );
    numSmoothPath++;

    // Move towards target a small advancement at a time until target reached or
    // when ran out of memory to store the path.
    while( npolys && numSmoothPath < MAX_SMOOTH )
    {
      // Find location to steer towards.
      float steerPos[ 3 ];
      uint8_t steerPosFlag;
      dtPolyRef steerPosRef;

      if( !getSteerTarget( m_naviMeshQuery, iterPos, targetPos, SLOP,
                           polys, npolys, steerPos, steerPosFlag, steerPosRef ) )
        break;

      bool endOfPath = ( steerPosFlag & DT_STRAIGHTPATH_END ) ? true : false;
      bool offMeshConnection = ( steerPosFlag & DT_STRAIGHTPATH_OFFMESH_CONNECTION ) ? true : false;

      // Find movement delta.
      float delta[ 3 ], len;
      dtVsub( delta, steerPos, iterPos );
      len = dtMathSqrtf( dtVdot( delta, delta ) );
      // If the steer target is end of path or off-mesh link, do not move past the location.
      if( ( endOfPath || offMeshConnection ) && len < STEP_SIZE )
        len = 1;
      else
        len = STEP_SIZE / len;
      float moveTgt[ 3 ];
      dtVmad( moveTgt, iterPos, delta, len );

      // Move
      float result[ 3 ];
      dtPolyRef visited[ 16 ];
      int32_t nvisited = 0;
      m_naviMeshQuery->moveAlongSurface( polys[ 0 ], iterPos, moveTgt, &filter,
                                         result, visited, &nvisited, 16 );

      npolys = fixupCorridor( polys, npolys, MAX_POLYS, visited, nvisited );
      npolys = fixupShortcuts( polys, npolys, m_naviMeshQuery );

      float h = 0;
      m_naviMeshQuery->getPolyHeight( polys[0], result, &h );
      result[ 1 ] = h;
      dtVcopy( iterPos, result );

      // Handle end of path and off-mesh links when close enough.
      if( endOfPath && inRange( iterPos, steerPos, SLOP, 1.0f ) )
      {
        // Reached end of path.
        dtVcopy( iterPos, targetPos );
        if( numSmoothPath < MAX_SMOOTH )
        {
          dtVcopy( &smoothPath[ numSmoothPath * 3 ], iterPos );
          numSmoothPath++;
        }
        break;
      }
      else if( offMeshConnection && inRange( iterPos, steerPos, SLOP, 1.0f ) )
      {
        // Reached off-mesh connection.
        float startPos[ 3 ], endPos[ 3 ];

        // Advance the path up to and over the off-mesh connection.
        dtPolyRef prevRef = 0, polyRef = polys[ 0 ];
        int32_t npos = 0;
        while( npos < npolys && polyRef != steerPosRef )
        {
          prevRef = polyRef;
          polyRef = polys[ npos ];
          npos++;
        }
        for( int32_t i = npos; i < npolys; ++i )
          polys[ i - npos ] = polys[ i ];
        npolys -= npos;

        // Handle the connection.
        dtStatus status = m_naviMesh->getOffMeshConnectionPolyEndPoints( prevRef, polyRef, startPos, endPos );
        if( dtStatusSucceed( status ) )
        {
          if( numSmoothPath < MAX_SMOOTH )
          {
            dtVcopy( &smoothPath[ numSmoothPath * 3 ], startPos );
            numSmoothPath++;
            // Hack to make the dotted path not visible during off-mesh connection.
            if( numSmoothPath & 1 )
            {
              dtVcopy( &smoothPath[ numSmoothPath * 3 ], startPos );
              numSmoothPath++;
            }
          }
          // Move position at the other side of the off-mesh link.
          dtVcopy( iterPos, endPos );
          float eh = 0.0f;
          m_naviMeshQuery->getPolyHeight( polys[ 0 ], iterPos, &eh );
          iterPos[ 1 ] = eh;
        }
      }

      // Store results.
      if( numSmoothPath < MAX_SMOOTH )
      {
        dtVcopy( &smoothPath[ numSmoothPath * 3 ], iterPos );
        numSmoothPath++;
      }
    }

    for( int32_t i = 0; i < numSmoothPath; i += 3 )
    {
      resultCoords.emplace_back( Common::Vector3{ smoothPath[ i ], smoothPath[ i + 1 ], smoothPath[ i + 2 ] } );
    }
  }

  return resultCoords;
}

bool Sapphire::Common::Navi::NaviProvider::loadMesh( const std::string& path )
{
  std::ifstream fp( path, std::ios::binary );
  if( !fp.is_open() )
  {
    Logger::error( "Couldn't open navimesh file: {0}", path );
    return false;
  }

  // Read header.
  TileCacheSetHeader header;
  fp.read( reinterpret_cast<char*>( &header ), sizeof( TileCacheSetHeader ) );
  if( !fp || header.magic != TILECACHESET_MAGIC || header.version != TILECACHESET_VERSION )
  {
    return false;
  }

  m_naviMesh = dtAllocNavMesh();
  if( !m_naviMesh )
  {
    return false;
  }
  
  dtStatus status = m_naviMesh->init( &header.meshParams );
  if( dtStatusFailed( status ) )
  {
    return false;
  }

  m_tileCache = dtAllocTileCache();
  if( !m_tileCache )
  {
    return false;
  }
  if( m_talloc )
    delete m_talloc;
  if( m_tcomp )
    delete m_tcomp;
  if( m_tmproc )
    delete m_tmproc;

  m_talloc = new LinearAllocator( 32000 );
  m_tcomp = new FastLZCompressor();
  m_tmproc = new MeshProcess();

  status = m_tileCache->init( &header.cacheParams, m_talloc, m_tcomp, m_tmproc );
  if( dtStatusFailed( status ) )
  {
    Logger::error( "dtTileCache::init failed with status {:#x} for zone {}", status, path );
    dtFreeTileCache( m_tileCache );
    m_tileCache = nullptr;
    return false;
  }

  auto resetNavMesh = [ this, &header, &path ]() -> bool
  {
    if( m_naviMesh )
    {
      dtFreeNavMesh( m_naviMesh );
      m_naviMesh = nullptr;
    }

    m_naviMesh = dtAllocNavMesh();
    if( !m_naviMesh )
    {
      Logger::error( "Unable to allocate navmesh while resetting cache load for {0}", path );
      return false;
    }

    dtStatus resetStatus = m_naviMesh->init( &header.meshParams );
    if( dtStatusFailed( resetStatus ) )
    {
      Logger::error( "Unable to reinitialize navmesh while resetting cache load for {0}", path );
      return false;
    }

    return true;
  };

  bool loadedFromCache = false;
  // todo: allow nav cache to be optional from config.ini??? unsure
  const std::filesystem::path navPath( path );
  const std::filesystem::path cachePath = getNavMeshCachePath( navPath );

  if( isNavMeshCacheFresh( navPath, cachePath ) )
  {
    std::string cacheError;
    if( loadNavMeshCache( cachePath, m_naviMesh, &cacheError ) )
    {
      loadedFromCache = true;
      Logger::info( "Loaded navmesh from fast-cache for {}", path );
    }
    else
    {
      Logger::warn( "Rejected navmesh cache {}: {}", cachePath.string(), cacheError );
      if( !resetNavMesh() )
      {
        return false;
      }
    }
  }

  const bool rebuildNavMesh = !loadedFromCache;

  // Read tiles.
  for( int i = 0; i < header.numTiles; ++i )
  {
    TileCacheTileHeader tileHeader;
    fp.read( reinterpret_cast<char*>( &tileHeader ), sizeof( tileHeader ) );
    if( !fp )
    {
      return false; // eof or navmesh is porked as hell
    }
    if( !tileHeader.tileRef || !tileHeader.dataSize )
      break;

    auto* data = static_cast< unsigned char* >( dtAlloc( tileHeader.dataSize, DT_ALLOC_PERM ) );
    if( !data ) break;
    memset( data, 0, tileHeader.dataSize );
    fp.read( reinterpret_cast< char* >( data ), tileHeader.dataSize );
    if( !fp )
    {
      dtFree( data );
      return false;
    }

    dtCompressedTileRef tile = 0;
    dtStatus addTileStatus = m_tileCache->addTile( data, tileHeader.dataSize, DT_COMPRESSEDTILE_FREE_DATA, &tile );
    if( dtStatusFailed( addTileStatus ) )
    {
      Logger::error( "[Navmesh] Unable to add tile to cache for {0}", path );
      dtFree( data );
    }

    if( tile && rebuildNavMesh )
      m_tileCache->buildNavMeshTile( tile, m_naviMesh );
  }

  fp.close();

  if( rebuildNavMesh )
  {
    std::string cacheError;
    if( writeNavMeshCache( cachePath, m_naviMesh, &cacheError ) )
    {
      Logger::info( "Created fast-cache navmesh for {}", path );
    }
    else
    {
      Logger::warn( "Unable to write fast-cache navmesh for {}: {}", path, cacheError );
    }
  }

  return true;
}

int32_t Sapphire::Common::Navi::NaviProvider::addAgent( const Common::Vector3& pos, float radius, float speed )
{
  dtCrowdAgentParams params{};
  std::memset( &params, 0, sizeof( params ) );
  params.height = 3.f;
  params.maxAcceleration = 40.f;
  params.maxSpeed = speed;
  params.radius = radius;
  params.collisionQueryRange = speed * 0.5f;
  params.pathOptimizationRange = speed * 3.0f;
  params.updateFlags = 0;
  params.updateFlags |= DT_CROWD_ANTICIPATE_TURNS |
                    DT_CROWD_OPTIMIZE_VIS |
                    DT_CROWD_OPTIMIZE_TOPO |
                    DT_CROWD_OBSTACLE_AVOIDANCE;
  params.separationWeight = 2.0f;
  params.obstacleAvoidanceType = 3;


  float position[] = { pos.x, pos.y, pos.z };
  return m_pCrowd->addAgent( position, &params );
}

void Sapphire::Common::Navi::NaviProvider::updateAgentParameters( int32_t naviAgentId, float radius, bool isRunning, float speed )
{
  if( naviAgentId == -1 )
    return;
  dtCrowdAgentParams params{};
  std::memset( &params, 0, sizeof( params ) );
  params.height = 3.f;
  params.maxAcceleration = 40.f;
  params.maxSpeed = speed;
  params.radius = radius;
  params.collisionQueryRange = speed * 0.5f;
  params.pathOptimizationRange = speed * 3.0f;
  params.updateFlags = 0;
  params.updateFlags |= DT_CROWD_ANTICIPATE_TURNS |
                    DT_CROWD_OPTIMIZE_VIS |
                    DT_CROWD_OPTIMIZE_TOPO |
                    DT_CROWD_OBSTACLE_AVOIDANCE;
  params.separationWeight = 2.0f;
  params.obstacleAvoidanceType = 3;
  m_pCrowd->updateAgentParameters( naviAgentId, &params );
}

void Sapphire::Common::Navi::NaviProvider::update( float timeInSeconds )
{
  dtCrowdAgentDebugInfo info{};
  info.idx = -1;
  info.vod = m_vod;

  m_tileCache->update( timeInSeconds, m_naviMesh );
  m_pCrowd->update( timeInSeconds, &info );
}

void Sapphire::Common::Navi::NaviProvider::removeAgent( int32_t naviAgentId )
{
  m_pCrowd->removeAgent( naviAgentId );
}

void Sapphire::Common::Navi::NaviProvider::calcVel( float* vel, const float* pos, const float* tgt, const float speed )
{
  dtVsub( vel, tgt, pos );
  vel[ 1 ] = 0.0;
  dtVnormalize( vel );
  dtVscale( vel, vel, speed );
}

void Sapphire::Common::Navi::NaviProvider::resetMoveTarget( int32_t naviAgentId )
{
  m_pCrowd->resetMoveTarget( naviAgentId );
}

void Sapphire::Common::Navi::NaviProvider::setMoveTarget( int32_t naviAgentId,
                                                         const Sapphire::Common::Vector3& endPos )
{
  // Find nearest point on navmesh and set move request to that location.
  dtNavMeshQuery* navquery = m_naviMeshQuery;

  const dtQueryFilter* filter = m_pCrowd->getFilter( 0 );
  const float* halfExtents = m_pCrowd->getQueryExtents();

  float p[ 3 ] = { endPos.x, endPos.y, endPos.z };

  dtPolyRef ref;

  auto status = m_naviMeshQuery->findNearestPoly( p, halfExtents, filter, &ref, nullptr );

  if( !dtStatusSucceed( status ) )
  {
    Logger::error( "Failed to find nearest poly for Chara-Agent#{} for pos X: {} Y: {} Z: {}",
                   naviAgentId, endPos.x, endPos.y, endPos.z );

    return;
  }

  const dtCrowdAgent* ag = m_pCrowd->getAgent( naviAgentId );
  if( ag && ag->active )
  {
    m_pCrowd->requestMoveTarget( naviAgentId, ref, p );
  }
}

Sapphire::Common::Vector3 Sapphire::Common::Navi::NaviProvider::getAgentPos( int32_t naviAgentId )
{
  const dtCrowdAgent* ag = m_pCrowd->getAgent( naviAgentId );
  if( !ag )
    return { 0.f, 0.f, 0.f };
  return { ag->npos[ 0 ], ag->npos[ 1 ], ag->npos[ 2 ] };
}

float Sapphire::Common::Navi::NaviProvider::getAgentSpeed( int32_t naviAgentId )
{
  const dtCrowdAgent* ag = m_pCrowd->getAgent( naviAgentId );
  if( !ag )
    return 0.f;

  // Get current velocity vector
  const float* vel = ag->vel;

  // Calculate speed (magnitude of velocity vector)
  float currentSpeed = sqrtf(vel[0] * vel[0] + vel[2] * vel[2]); // 2D speed (XZ plane)

  return currentSpeed;
}

bool Sapphire::Common::Navi::NaviProvider::isAgentActive( int32_t naviAgentId ) const
{
  const dtCrowdAgent* ag = m_pCrowd->getAgent( naviAgentId );
  return ag && ag->active;

}

bool Sapphire::Common::Navi::NaviProvider::hasTargetState( int32_t naviAgentId ) const
{
  const dtCrowdAgent* ag = m_pCrowd->getAgent( naviAgentId );
  return ag->targetState != DT_CROWDAGENT_TARGET_NONE;
}

int32_t Sapphire::Common::Navi::NaviProvider::updateAgentPosition( int32_t naviAgentId, const Common::Vector3& pos, float radius, float speed )
{
  resetMoveTarget( naviAgentId );
  removeAgent( naviAgentId );
  auto newIndex = addAgent( pos, radius, speed );
  return newIndex;
}

void Sapphire::Common::Navi::NaviProvider::addAgentUpdateFlag( int32_t naviAgentId, uint8_t flags )
{
  auto ag = m_pCrowd->getEditableAgent( naviAgentId );

  if( !ag )
    return;

  ag->params.updateFlags |= flags;
}

void Sapphire::Common::Navi::NaviProvider::removeAgentUpdateFlag( int32_t naviAgentId, uint8_t flags )
{
  auto ag = m_pCrowd->getEditableAgent( naviAgentId );

  if( !ag )
    return;

  ag->params.updateFlags &= ~flags;
}

void Sapphire::Common::Navi::NaviProvider::toggleBox( dtObstacleRef& obstacleRef, const Common::Vector3& pos,
                                                       const Common::Vector3& halfExtents, float rot, bool enabled )
{
  float fpos[ 3 ] = { pos.x, pos.y, pos.z };
  // Half-extents: Width, Height, Depth
  float fhalfExtents[ 3 ] = { halfExtents.x, halfExtents.y, halfExtents.z };

  if( obstacleRef != 0 && enabled )
  {
    m_tileCache->removeObstacle( obstacleRef );
    obstacleRef = 0;
  }

  if( enabled && obstacleRef == 0 )
  {
    auto status = m_tileCache->addBoxObstacle( fpos, fhalfExtents, rot, &obstacleRef );
    if( dtStatusFailed( status ) )
      Logger::error( "[Navmesh] addBoxObstacle failed (request queue full?) at X:{} Y:{} Z:{}",
                     pos.x, pos.y, pos.z );
  }
  else if( !enabled && obstacleRef != 0 )
  {
    // REMOVE: Use the previously assigned doorRef to identify the obstacle
    m_tileCache->removeObstacle( obstacleRef );
    // RESET: Clear the handle so the system knows the door is "free"
    obstacleRef = 0;
  }
}

void Sapphire::Common::Navi::NaviProvider::toggleObstacle( dtObstacleRef& obstacleRef, const Common::Vector3& pos, float radius, float height, bool enabled )
{
  float fpos[ 3 ] = { pos.x, pos.y, pos.z };

  if( obstacleRef != 0 && enabled )
  {
    m_tileCache->removeObstacle( obstacleRef );
    obstacleRef = 0;
  }

  if( enabled && obstacleRef == 0 )
  {
    auto status = m_tileCache->addObstacle( fpos, radius, height, &obstacleRef );
    if( dtStatusFailed( status ) )
      Logger::error( "[Navmesh] addObstacle failed (request queue full?) at X:{} Y:{} Z:{}",
                     pos.x, pos.y, pos.z );
  }
  else if( !enabled && obstacleRef != 0 )
  {
    // REMOVE: Use the previously assigned doorRef to identify the obstacle
    m_tileCache->removeObstacle( obstacleRef );
    // RESET: Clear the handle so the system knows the door is "free"
    obstacleRef = 0;
  }
}

bool Sapphire::Common::Navi::NaviProvider::hasLineOfSight( const Common::Vector3& startPos, const Common::Vector3& endPos )
{
  if( m_naviMeshQuery == nullptr )
  {
    Logger::error( "[Navmesh] hasLineOfSight: m_naviMeshQuery is null" );
    return true;
  }

  dtQueryFilter filter;
  // 1. DETOUR CHECK: Is the path clear on the NavMesh?
  dtPolyRef startRef{ 0 };
  float nearestPt[ 3 ];
  float extents[ 3 ] = { 2.0f, 4.0f, 2.0f };
  float fstartPos[ 3 ] = { startPos.x, startPos.y, startPos.z };
  float fendPos[ 3 ] = { endPos.x, endPos.y, endPos.z };
  m_naviMeshQuery->findNearestPoly( fstartPos, extents, &filter, &startRef, nearestPt );

  dtRaycastHit navHit{ 0 };
  m_naviMeshQuery->raycast( startRef, fstartPos, fendPos, &filter, 0, &navHit );

  // If navHit.t < 1.0, the ray hit a NavMesh boundary (a wall or a hole)
  if( navHit.t < 1.0f )
  {
    return false;
  }

  return true;// Both checks passed
}
