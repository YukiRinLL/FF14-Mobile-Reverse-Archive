#pragma once

#include <string>
#include <vector>
#include <map>
#include <memory>
#include "PlayerMinimal.h"

namespace Sapphire::Api
{
  class Session;

  class SapphireApi
  {
  public:
    SapphireApi() = default;
    ~SapphireApi() = default;

    using SessionMap = std::map< std::string, std::shared_ptr< Session > >;

    bool login( const std::string& username, const std::string& pass, std::string& sId );

    bool createAccount( const std::string& username, const std::string& pass, std::string& sId );

    int32_t createCharacter( uint32_t accountId, const std::string& name,
                             const std::string& infoJson, uint32_t gmRank );

    void deleteCharacter( std::string name, uint32_t accountId );

    bool insertSession( uint32_t accountId, std::string& sId );

    std::vector< Api::PlayerMinimal > getCharList( uint32_t accountId );

    bool checkNameTaken( std::string_view name );

    uint32_t getNextEntityId();

    uint64_t getNextCharaId();

    int32_t checkSession( const std::string& sId );

    bool removeSession( const std::string& sId );

    SessionMap m_sessionMap;

  };
}
