#include <ScriptObject.h>
#include <Territory/InstanceContent.h>
#include <Actor/EventObject.h>

using namespace Sapphire;

class TheWanderersPalace : public Sapphire::ScriptAPI::InstanceContentScript
{
public:
  TheWanderersPalace() : Sapphire::ScriptAPI::InstanceContentScript( 10 )
  { }

  void onInit( InstanceContent& instance ) override
  {
    Entity::EventObjectPtr pEObj;

    pEObj = instance.addEObj( "unknown_0", 2001809, 0, 4177841, 4, { 134.115601f, -17.997431f, 473.641693f }, 1.000000f, 0.000000f, 0 ); 

    pEObj = instance.addEObj( "Shortcut", 2000700, 0, 4177843, 4, { 137.299393f, -17.990360f, 454.401398f }, 0.991760f, 0.000048f, 0 ); 

    pEObj = instance.addEObj( "unknown_1", 2001822, 4086687, 4177864, 4, { 125.014000f, -9.459579f, 64.149277f }, 1.000000f, 0.000000f, 0 ); 
    pEObj->addCollisionBox( { 125.021729, -4.407557, 64.141663 }, -0.000000, 2.549497, 5.557225, 0.184762 );

    pEObj = instance.addEObj( "unknown_3", 2001823, 4323504, 4177865, 4, { 117.995003f, -7.766907f, 65.232300f }, 0.991760f, 0.000048f, 0 ); 

    pEObj = instance.addEObj( "unknown_5", 2001824, 4086767, 4177866, 4, { 43.140591f, 0.499020f, -29.383511f }, 1.000000f, 0.000000f, 0 ); 
    pEObj->addCollisionBox( { 43.140591, 3.776582, -29.384050 }, -0.000000, 2.336065, 3.605318, 0.130123 );

    pEObj = instance.addEObj( "unknown_13", 2001825, 4323511, 4177867, 4, { 35.027500f, 2.231338f, -5.969540f }, 0.991760f, 0.000048f, 0 ); 

    pEObj = instance.addEObj( "unknown_14", 2001826, 4323509, 4177868, 4, { 34.988789f, 2.301583f, -28.158291f }, 1.000000f, 0.000000f, 0 ); 

    pEObj = instance.addEObj( "Exit", 2000139, 0, 4178207, 4, { 73.105957f, 9.994568f, -475.590790f }, 0.991760f, 0.000048f, 0 ); 

    pEObj = instance.addEObj( "Entrance", 2000182, 4177700, 4178323, 5, { 130.745697f, -17.983120f, 461.438293f }, 1.000000f, 0.000000f, 0 ); 
    // States -> vf_lock_on (id: 11) vf_lock_of (id: 12) 
    pEObj->addCollisionBox( { 130.745697, -15.983120, 458.438293 }, -0.000000, 1.300000, 4.000000, 0.250000 );
    pEObj->addCollisionBox( { 130.755493, -15.983120, 464.438293 }, -0.000000, 1.300000, 4.000000, 0.250000 );
    pEObj->addCollisionBox( { 133.745697, -15.983120, 461.442169 }, -1.570451, 1.300000, 4.000000, 0.250000 );
    pEObj->addCollisionBox( { 127.745697, -15.983120, 461.449280 }, -1.570451, 1.300000, 4.000000, 0.250000 );
    pEObj->addCollisionBox( { 128.645691, -15.983120, 459.338287 }, -0.785398, 1.400000, 4.000000, 0.250000 );
    pEObj->addCollisionBox( { 132.845703, -15.983120, 463.538300 }, -0.785398, 1.400000, 4.000000, 0.250000 );
    pEObj->addCollisionBox( { 132.845703, -15.983120, 459.338287 }, 0.785398, 1.400000, 4.000000, 0.250000 );
    pEObj->addCollisionBox( { 128.645691, -15.983120, 463.538300 }, 0.785398, 1.400000, 4.000000, 0.250000 );

    pEObj = instance.addEObj( "unknown_15", 2001828, 4323513, 4178334, 4, { 43.003689f, 2.351689f, -58.849869f }, 1.000000f, 0.000000f, 0 ); 

    pEObj = instance.addEObj( "unknown_16", 2001829, 4323516, 4178335, 4, { 54.100830f, 10.258660f, -95.915703f }, 0.991760f, 0.000048f, 0 ); 

    pEObj = instance.addEObj( "unknown_17", 2001830, 4323519, 4178337, 4, { 121.982201f, 2.305465f, -145.991302f }, 0.991760f, 0.000048f, 0 ); 

    pEObj = instance.addEObj( "unknown_18", 2001831, 4323523, 4178339, 4, { 35.995869f, 2.276821f, -151.081100f }, 0.991760f, 0.000048f, 0 ); 

    pEObj = instance.addEObj( "unknown_6", 2001827, 4086770, 4178340, 4, { 43.011742f, 0.540422f, -152.602997f }, 1.000000f, 0.000000f, 0 ); 
    pEObj->addCollisionBox( { 43.019466, 5.592443, -152.610611 }, -0.000000, 2.549497, 5.557225, 0.184762 );

    pEObj = instance.addEObj( "unknown_19", 2001832, 4086777, 4178341, 4, { 73.005737f, 10.540420f, -380.487610f }, 1.000000f, 0.000000f, 0 ); 
    pEObj->addCollisionBox( { 73.013458, 15.592442, -380.495239 }, -0.000000, 2.549497, 5.557225, 0.184762 );

    pEObj = instance.addEObj( "unknown_22", 2001833, 4323531, 4178342, 4, { 81.010132f, 12.313960f, -380.117493f }, 0.991760f, 0.000048f, 0 ); 

    pEObj = instance.addEObj( "unknown_23", 2001834, 4323529, 4178343, 4, { 65.001831f, 12.381110f, -380.103790f }, 1.000000f, 0.000000f, 0 ); 

    pEObj = instance.addEObj( "sgvf_w_lvd_b0094", 2001810, 4259126, 4178384, 4, { 124.986603f, -12.039370f, 125.401100f }, 0.991760f, 0.000048f, 0 ); 
    // States -> vf_line_on (id: 12) vf_line_of (id: 13) 

    pEObj = instance.addEObj( "sgvf_w_lvd_b0094_1", 2001812, 4259127, 4178388, 4, { 43.121960f, -0.015320f, -212.616592f }, 0.991760f, 0.000048f, 0 ); 
    // States -> vf_line_on (id: 12) vf_line_of (id: 13) 

    pEObj = instance.addEObj( "sgpl_s1d3_bossline", 2001814, 4239448, 4236779, 4, { 72.890900f, 9.976854f, -400.332489f }, 1.000000f, 0.000000f, 0 ); 

    pEObj = instance.addEObj( "sgpl_s1d3_bosswall", 2001815, 4239449, 4236782, 4, { 74.758614f, 9.976894f, -400.332489f }, 1.000000f, 0.000000f, 0 ); 
    pEObj->addCollisionBox( { 92.881912, 13.323295, -385.929901 }, -0.495185, 9.000000, 4.000000, 0.750000 );
    pEObj->addCollisionBox( { 57.476513, 13.323295, -385.332489 }, 0.488692, 9.000000, 4.000000, 0.750000 );

    pEObj = instance.addEObj( "sgvf_w_lvd_b0118", 2001811, 4259124, 4236783, 4, { 127.094200f, -12.000000f, 125.826500f }, 1.000000f, 0.000000f, 0 ); 
    // States -> vf_bextwall_on (id: 3) vf_bextwall_of (id: 4) 
    pEObj->addCollisionBox( { 127.094200, -9.500000, 125.826500 }, -0.000000, 7.500000, 4.000000, 0.750000 );

    pEObj = instance.addEObj( "sgvf_w_lvd_b0118_1", 2001813, 4259128, 4236784, 4, { 45.925018f, 0.000000f, -212.411499f }, 1.000000f, 0.000000f, 0 ); 
    // States -> vf_bextwall_on (id: 3) vf_bextwall_of (id: 4) 
    pEObj->addCollisionBox( { 45.925018, 2.500000, -212.411499 }, -0.000000, 7.500000, 4.000000, 0.750000 );

    pEObj = instance.addEObj( "sgvf_w_lvd_b0250", 2000277, 4259125, 4259138, 4, { 125.461502f, -12.000000f, 89.079697f }, 1.000000f, 0.000000f, 0 ); 
    // States -> vf_bextwall_on (id: 3) vf_bextwall_of (id: 4) 
    pEObj->addCollisionBox( { 125.461502, -9.500000, 89.079697 }, -0.000000, 15.000000, 4.000000, 0.750000 );

    pEObj = instance.addEObj( "sgvf_w_lvd_b0118_2", 2000278, 4259129, 4259142, 4, { 43.493420f, -0.100058f, -248.056198f }, 1.000000f, 0.000000f, 0 ); 
    // States -> vf_bextwall_on (id: 3) vf_bextwall_of (id: 4) 
    pEObj->addCollisionBox( { 43.493420, 2.399942, -248.056198 }, -0.000000, 7.500000, 4.000000, 0.750000 );

    pEObj = instance.addEObj( "unknown_2", 2001114, 4323503, 4323774, 4, { 118.000000f, -8.700125f, 65.370102f }, 1.000000f, 0.000000f, 0 ); 

    pEObj = instance.addEObj( "unknown_7", 2001115, 4323510, 4323775, 4, { 35.000000f, 1.250271f, -5.876968f }, 1.000000f, 0.000000f, 0 ); 

    pEObj = instance.addEObj( "unknown_8", 2001116, 4323508, 4323776, 4, { 35.000000f, 1.249865f, -28.099899f }, 1.000000f, 0.000000f, 0 ); 

    pEObj = instance.addEObj( "unknown_9", 2001117, 4323512, 4323778, 4, { 43.000000f, 1.300663f, -58.799179f }, 1.000000f, 0.000000f, 0 ); 

    pEObj = instance.addEObj( "unknown_10", 2001118, 4323515, 4323779, 4, { 54.099178f, 9.249764f, -95.999512f }, 1.000000f, 1.570451f, 0 ); 

    pEObj = instance.addEObj( "unknown_11", 2001119, 4323518, 4323780, 4, { 122.099899f, 1.250139f, -145.999405f }, 1.000000f, 1.570451f, 0 ); 

    pEObj = instance.addEObj( "unknown_12", 2001120, 4323522, 4323781, 4, { 36.000000f, 1.299810f, -151.049896f }, 1.000000f, 0.000000f, 0 ); 

    pEObj = instance.addEObj( "unknown_21", 2001122, 4323528, 4323782, 4, { 65.000000f, 11.249720f, -380.099792f }, 1.000000f, 0.000000f, 0 ); 

    pEObj = instance.addEObj( "unknown_20", 2001121, 4323530, 4323783, 4, { 80.979607f, 11.245850f, -380.117493f }, 0.991760f, 0.000048f, 0 ); 

    pEObj = instance.addEObj( "Nymiandevice", 2001123, 4126926, 4323825, 4, { 117.995003f, -9.001419f, 65.378754f }, 0.991760f, 0.000048f, 0 ); 

    pEObj = instance.addEObj( "RustedNymiandevice", 2001124, 4126931, 4324149, 4, { 34.988892f, 0.930786f, -6.393555f }, 0.991760f, 0.000048f, 0 ); 

    pEObj = instance.addEObj( "RustedNymiandevice_1", 2001125, 4126938, 4324150, 4, { 34.988892f, 0.930786f, -27.634159f }, 0.991760f, 0.000048f, 0 ); 

    pEObj = instance.addEObj( "RustedNymiandevice_2", 2001126, 4126941, 4324151, 4, { 42.984619f, 0.991760f, -58.335270f }, 0.991760f, 0.000048f, 0 ); 

    pEObj = instance.addEObj( "Nymiandevice_1", 2001127, 4126947, 4324152, 4, { 53.613361f, 8.952527f, -95.999352f }, 1.000000f, 1.570451f, 0 ); 

    pEObj = instance.addEObj( "RustedNymiandevice_3", 2001128, 4126952, 4324153, 4, { 121.629601f, 0.930786f, -146.013596f }, 0.991760f, 1.570451f, 0 ); 

    pEObj = instance.addEObj( "RustedNymiandevice_4", 2001129, 4126956, 4324154, 4, { 35.995972f, 0.991760f, -150.591400f }, 0.991760f, 0.000048f, 0 ); 

    pEObj = instance.addEObj( "RustedNymiandevice_5", 2001130, 4126964, 4324155, 4, { 80.979607f, 10.940670f, -379.629211f }, 0.991760f, 0.000048f, 0 ); 

    pEObj = instance.addEObj( "RustedNymiandevice_6", 2001131, 4126966, 4324156, 4, { 64.988159f, 10.940670f, -379.629211f }, 0.991760f, 0.000048f, 0 ); 

    pEObj = instance.addEObj( "unknown_4", 2002790, 4405761, 4405900, 4, { 125.029999f, -13.277490f, 181.098602f }, 1.000000f, 0.000000f, 0 ); 
    pEObj->addCollisionBox( { 125.029999, -9.999928, 181.098068 }, -0.000000, 2.336065, 3.605318, 0.130123 );

    pEObj = instance.addEObj( "Lanternoil", 2002789, 0, 4405902, 4, { 35.621380f, -0.164260f, -23.125179f }, 1.000000f, 0.000000f, 0 ); 

    pEObj = instance.addEObj( "sgvf_w_lvd_b0118_3", 2005197, 5674883, 5674890, 4, { 73.492577f, 6.000000f, -464.485596f }, 1.000000f, 0.000000f, 0 ); 
    // States -> vf_bextwall_on (id: 3) vf_bextwall_of (id: 4) 
    pEObj->addCollisionBox( { 73.492577, 8.500000, -464.485596 }, -0.000000, 7.500000, 4.000000, 0.750000 );


  }

  void onUpdate( InstanceContent& instance, uint64_t tickCount ) override
  {

  }

  void onTalk( InstanceContent& instance, Entity::Player& player, Entity::EventObject& eobj, uint32_t eventId ) override
  {

  }

  void onTalk( InstanceContent& instance, Entity::Player& player, uint32_t eventId, uint64_t actorId ) override
  {

  }

  void onEnterTerritory( InstanceContent& instance, Entity::Player& player, uint32_t eventId, uint16_t param1,
                         uint16_t param2 ) override
  {

  }

  void onLeaveTerritory( InstanceContent& instance, Entity::Player& player ) override
  {

  }

};

EXPOSE_SCRIPT( TheWanderersPalace );